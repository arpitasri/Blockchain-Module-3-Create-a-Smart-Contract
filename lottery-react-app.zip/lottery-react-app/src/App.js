import React from 'react';
import logo from './logo.svg';
import './App.css';
import web3 from './web3';
import lottery from './lottery';

//function App() {
  export default class App extends React.Component {

    state = {
      manager : '',
      players: [],
      balance: '',
      value: '',
      message: ''
    };

    // constructor(props){
    //   super(props);
    //   this.state = {manager: ''};
    // }

  async componentDidMount(){
    const manager = await lottery.methods.manager().call();
    const players = await lottery.methods.getPlayers().call();
    const balance = await web3.eth.getBalance(lottery.options.address);
    this.setState({manager, players, balance});
  }

  onSubmit = async event =>{
    try{
      //event.preventDefault();
      if(this.state.value != null && this.state.value != "")
      {
        debugger;
        const accounts = await web3.eth.getAccounts();
        this.setState({message: 'Waiting on transaction success......'});
        await lottery.methods.enter().send({
          from : accounts[0],
          value: web3.utils.toWei(this.state.value, 'ether')
        });
        this.setState({message : 'You have been Entered'});
        //window.location.reload();
      }
      else
      {
        this.setState({message : 'Please Enter Amount in Textbox!!'});
      }
    }
    catch(err)
    {
      this.setState({message : 'Sorry, Transaction Failed!'});
    }
    finally
    {
      this.setState({message : ''});
    }
  };

  onClick = async () =>{
    try{
    const accounts = await web3.eth.getAccounts();
    this.setState({message: 'Waiting on transaction success......'});  
      await lottery.methods.pickWinner().send({
        from: accounts[0]
    });
    this.setState({message : 'A winner has been picked!'});
    }
    catch(err)
    {
      this.setState({message : 'Sorry, Transaction Failed!'});
    }
    finally
    {
      this.setState({message : ''});
      //window.location.reload();
    }
  };

  render(){
  return (
    <div class="container-fluid hero" style={{marginTop : '20px'}}>
    <div class="container">
      <h2 class="text-center">Lottery Contract</h2>
      <p class="text-center">
        This Contract is managed by <label class="font-weight-bold">{this.state.manager}</label>.
        There are currently <label class="font-weight-bold">{this.state.players.length}</label> people entered, competing
        to win <label class="font-weight-bold">{web3.utils.fromWei(this.state.balance,'ether')}</label> ether!
        </p>
        <hr/>
          <h6 class="text-center" style={{color: 'red'}}>{this.state.message}</h6>
        <form onSubmit={this.onSubmit}>
          <h4>Want to try your luck?</h4>
          <div class="form-inline">
            <div class="form-group">
            <label>Amount of ether to enter:&nbsp;</label>
            <input value={this.state.value} class="form-control"
            onChange={event => this.setState({value: event.target.value})} />
            &nbsp;&nbsp;
            <button class="btn btn-primary">Enter</button>
            </div>
          </div>
          <hr/>
          <div class="form-inline">
            <div class="form-group">
            <h4>Ready to pick a winner?</h4>&nbsp;&nbsp;
          <button onClick={this.onClick} class="btn btn-success">Pick a winner!</button>
            </div>
          </div>
        </form>
    </div>
    </div>
  );
}
}
  //export default App;